# https://www.guru99.com/fr/python-tutorials.html
